/* freebsd8 is a superset of freebsd4 */
#include "freebsd7.h"
#define freebsd7 freebsd7
