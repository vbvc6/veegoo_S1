/*
 *  memory quantity mib groups
 *
 */
#ifndef _MIBGROUP_MEMORY_AIX4_H
#define _MIBGROUP_MEMORY_AIX4_H

#include "mibdefs.h"

void            init_memory_aix4(void);

#endif                          /* _MIBGROUP_MEMORY_AIX4_H */
